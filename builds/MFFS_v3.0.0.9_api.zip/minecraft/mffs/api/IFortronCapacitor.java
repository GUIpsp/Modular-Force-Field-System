package mffs.api;

import java.util.Set;

public interface IFortronCapacitor
{
	public Set<IFortronFrequency> getLinkedDevices();
}
