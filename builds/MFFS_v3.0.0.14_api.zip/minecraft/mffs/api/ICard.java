package mffs.api;

public interface ICard
{

}
