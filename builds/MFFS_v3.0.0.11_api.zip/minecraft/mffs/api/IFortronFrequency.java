package mffs.api;

import icbm.api.IBlockFrequency;

public interface IFortronFrequency extends IFortronStorage, IBlockFrequency
{

}
