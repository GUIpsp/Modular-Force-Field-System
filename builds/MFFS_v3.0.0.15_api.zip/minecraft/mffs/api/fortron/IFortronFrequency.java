package mffs.api.fortron;

import icbm.api.IBlockFrequency;

public interface IFortronFrequency extends IFortronStorage, IBlockFrequency
{

}
